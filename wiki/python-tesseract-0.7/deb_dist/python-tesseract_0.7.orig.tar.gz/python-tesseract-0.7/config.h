#ifndef __linux__
	#define __linux__
#endif
