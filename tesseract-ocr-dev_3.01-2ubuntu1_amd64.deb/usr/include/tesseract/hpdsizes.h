#ifndef           HPDSIZES_H
#define           HPDSIZES_H

#define NUM_TEXT_ATTR   10
#define NUM_BLOCK_ATTR   7
#define MAXLENGTH 128
#define NUM_BACKGROUNDS   8
#endif
